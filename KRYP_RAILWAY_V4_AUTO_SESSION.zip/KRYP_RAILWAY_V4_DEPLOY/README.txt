KRYP Railway V4 - Automatic Session Connection

Files:
- index.html
- kryp-remote-server.js
- package.json

What changed:
- Customer browsers automatically obtain a short-lived realtime session; no Railway CUSTOMER_TOKEN popup.
- Admin gets a short-lived realtime session after the existing admin login; no Railway ADMIN_TOKEN popup.
- Existing token authentication remains supported as a fallback.
- WebSocket and API replay accept session authentication.
- Root URL serves index.html.
- Existing event deduplication remains in place.

Railway variables:
- ADMIN_TOKEN (keep existing)
- CUSTOMER_TOKEN (keep existing)
- ADMIN_PASSWORD (optional; if omitted, compatibility default is admin006)
- SESSION_TTL_MS (optional; default 12 hours)
- MAX_EVENTS (keep existing)

IMPORTANT:
Do not put ADMIN_TOKEN or CUSTOMER_TOKEN into chat or public code. Change ADMIN_PASSWORD in Railway Variables to a private value before production use.
